---
name: Aurelian Standard
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393d'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b1f'
  surface-container: '#1e1f23'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343539'
  on-surface: '#e3e2e7'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e3e2e7'
  inverse-on-surface: '#2f3034'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#d0cdcd'
  on-tertiary: '#313030'
  tertiary-container: '#b4b2b2'
  on-tertiary-container: '#454544'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#121317'
  on-background: '#e3e2e7'
  surface-variant: '#343539'
typography:
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  data-display:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
---

## Brand & Style

The design system is engineered to evoke an atmosphere of "Luxury Fintech"—a digital environment that feels like an exclusive private banking lounge. The target audience consists of high-net-worth individuals and institutional players who value precision, discretion, and understated elegance.

The aesthetic direction is a fusion of **Minimalism** and **High-End Editorial**. It prioritizes vast amounts of whitespace (negative space) to allow information to breathe, suggesting that the user's time and focus are the ultimate luxuries. The UI is characterized by razor-sharp precision, utilizing hairline borders and a "dark mode by default" philosophy to create a sense of depth and prestige. The emotional response should be one of calm confidence and absolute reliability.

## Colors

The palette is anchored in **Ebony (#121212)** and **Obsidian (#0A0A0A)** to provide a deep, infinite backdrop. **Champagne Gold (#D4AF37)** is used sparingly as the primary accent color for critical actions, active states, and brand moments, ensuring it remains a symbol of value rather than a utility.

Secondary surfaces use **Carbon (#1A1A1A)** to create subtle differentiation in the hierarchy. For data visualization and secondary text, a range of muted greys and "cool silvers" are employed to maintain high legibility without breaking the dark, sophisticated aesthetic. Gradients should be extremely subtle, moving from a slightly lighter charcoal to ebony to simulate the sheen of brushed metal or high-quality leather.

## Typography

This design system utilizes a sophisticated tripartite typographic scale:
1.  **Display & Headings:** *Playfair Display* provides a classic, editorial authority. It should be used for large titles and section headers to establish a premium tone.
2.  **Body & UI:** *Plus Jakarta Sans* offers a modern, high-quality sans-serif experience that is exceptionally legible on digital screens while feeling softer and more welcoming than standard system fonts.
3.  **Technical Data:** *JetBrains Mono* is used exclusively for numerical data, currency values, and timestamps. This reinforces the "Fintech" aspect of the brand, signaling technical precision and accuracy.

All uppercase labels should utilize increased letter spacing (tracking) to enhance the feeling of "luxury branding."

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** model for desktop to maintain strict editorial control, transitioning to a fluid model for smaller breakpoints.

- **Desktop (1440px+):** A 12-column grid with generous 80px side margins. This "intentional waste" of space creates the premium feel of a high-end magazine.
- **Tablet (768px - 1024px):** 8-column grid with 40px margins.
- **Mobile (Below 768px):** 4-column grid with 20px margins.

Spacing follows a strict 8px base unit. Component internal padding should be generous; for example, a card should never have less than 32px of internal padding (4x units) to prevent information from feeling "cramped" or "cheap."

## Elevation & Depth

Elevation in this design system is achieved through **Tonal Layering** and **Fine Outlines** rather than heavy shadows.

- **Layers:** The base background is the darkest level (#0A0A0A). Primary containers sit one level above (#121212). Floating elements like menus or modals sit at the third level (#1A1A1A).
- **Precision Lines:** Surfaces are defined by 0.5pt or 1pt borders. Use a subtle Gold-to-Transparent gradient for borders on primary elements, and a muted "Carbon" border (#2C2C2C) for secondary elements.
- **Shadows:** If shadows are necessary for depth (e.g., on a floating modal), use a very large blur (40px+) with very low opacity (15%) to create an "ambient glow" rather than a hard drop shadow.

## Shapes

The shape language is **Soft (Level 1)**. While sharp corners feel aggressive, overly rounded "pill" shapes feel too casual or "bubbly" for a high-end fintech product. 

- **Standard Elements:** 4px (0.25rem) radius. This provides a subtle hint of modern refinement while maintaining a structured, architectural feel.
- **Large Containers:** 8px (0.5rem) radius for cards and main content areas.
- **Buttons:** 4px radius, maintaining the consistent sharp-yet-refined silhouette.

## Components

- **Buttons:** Primary buttons use a subtle vertical gradient of Champagne Gold (#D4AF37 to #B8962E) with black text. Secondary buttons are "Ghost" style with a 1px Champagne Gold border and gold text.
- **Input Fields:** Use a bottom-border-only design or a very dark background (#0A0A0A) with a 0.5px silver-grey border. On focus, the border transitions to Champagne Gold.
- **Cards:** Cards should have no background fill (transparent) with a 1px #2C2C2C border, or a solid #121212 fill with no border. This "flat depth" approach is key to the aesthetic.
- **Chips/Tags:** Small, rectangular with 2px radius. Use JetBrains Mono for the text within chips to emphasize the data-driven nature.
- **Charts:** Use thin, 1.5px lines for line charts. Use Champagne Gold for the primary data line and a muted silver for secondary benchmarks. Area charts should use a faint gold-to-transparent gradient fill.
- **Lists:** Separate list items with 0.5px hairline dividers. Ensure generous vertical padding (minimum 16px) between items.